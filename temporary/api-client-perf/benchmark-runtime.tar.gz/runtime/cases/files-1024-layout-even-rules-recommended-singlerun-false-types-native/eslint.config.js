import tseslint from "typescript-eslint";

export default tseslint.config(tseslint.configs.recommendedTypeChecked, {
	files: ["**/*.ts"],
	languageOptions: {
		parserOptions: {
			disallowAutomaticSingleRunInference: true,
			projectService: { EXPERIMENTAL_backend: "native" },
			tsconfigRootDir: import.meta.dirname,
		},
	},
	rules: {
		"@typescript-eslint/no-floating-promises": "error",
	},
});
