export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export type Status3 = "active" | "archived" | "pending";

export interface Item3 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status3;
	tags: readonly string[];
}

export type ItemPatch3 = Partial<Omit<Item3, "createdAt" | "id">>;

export type Getters3<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped3<T> = T extends Promise<infer U> ? U : T;

export type Result3<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary3 {
	byStatus: Record<Status3, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses3 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status3[];

export class Repository3<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result3<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch3 & Partial<T>,
	): Promise<Result3<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe3(value: Date): string;
export function describe3(value: number): string;
export function describe3(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem3(prefix: string, offset: number): Item3 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-3-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe3(offset)}`,
		status: statuses3[offset % statuses3.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize3(
	items: readonly Item3[],
	dependencies: number,
): Summary3 {
	const byStatus: Record<Status3, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example3(prefix: string): Promise<Summary3> {
	const repository = new Repository3<Item3>(`${prefix}repository3`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem3(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-3-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);

	const summary: Unwrapped3<ReturnType<typeof example3>> = summarize3(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters3<Summary3>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
