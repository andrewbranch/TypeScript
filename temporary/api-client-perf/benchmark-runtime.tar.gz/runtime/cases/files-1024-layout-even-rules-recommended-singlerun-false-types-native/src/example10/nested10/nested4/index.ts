export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";

export interface Summary3 {
	total: number;
}

export async function example3(prefix: string): Promise<Summary3> {
	await Promise.resolve();
	return { total: prefix.length + 3 };
}
