export interface Summary0 {
	failures: string[];
	total: number;
}

export type Result0<T> = { error: string; ok: false } | { ok: true; value: T };

export type Event0 =
	| { amount: number; kind: "deposit" }
	| { amount: number; kind: "withdrawal" }
	| { kind: "close"; reason: string };

export function parseAmount0(input: string): Result0<number> {
	const amount = Number(input);
	return Number.isFinite(amount) && amount >= 0
		? { ok: true, value: amount }
		: { error: `Invalid amount: ${input}`, ok: false };
}

export function applyEvent0(balance: number, event: Event0): Result0<number> {
	switch (event.kind) {
		case "close":
			return balance === 0
				? { ok: true, value: 0 }
				: { error: `Cannot close: ${event.reason}`, ok: false };
		case "deposit":
			return { ok: true, value: balance + event.amount };
		case "withdrawal":
			return event.amount > balance
				? { error: "Insufficient funds", ok: false }
				: { ok: true, value: balance - event.amount };
	}
}

export async function example0(prefix: string): Promise<Summary0> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const failures: string[] = [];
	let balance = 0;
	for (const input of [prefix.length.toString(), "12", "-3"]) {
		const amount = parseAmount0(input);
		if (!amount.ok) {
			failures.push(amount.error);
			continue;
		}

		const applied = applyEvent0(balance, {
			amount: amount.value,
			kind: "deposit",
		});
		if (applied.ok) {
			balance = applied.value;
		} else {
			failures.push(applied.error);
		}
	}

	return { failures, total: balance + dependencyTotal };
}
