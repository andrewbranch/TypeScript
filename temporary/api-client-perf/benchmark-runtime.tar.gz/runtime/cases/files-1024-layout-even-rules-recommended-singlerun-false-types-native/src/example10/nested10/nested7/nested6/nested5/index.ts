export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary4 {
	labels: string[];
	total: number;
}

interface Entry4 {
	count: number;
	label: string;
}

const entries4: Entry4[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry4(entry: Entry4): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example4(prefix: string): Promise<Summary4> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const labels = entries4
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry4(entry));

	return { labels, total: labels.length + dependencyTotal };
}
