export interface Summary1 {
	total: number;
}

export async function example1(prefix: string): Promise<Summary1> {
	await Promise.resolve();
	return { total: prefix.length + 1 };
}
