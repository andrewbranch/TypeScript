export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";
export * as nested5 from "./nested5/index.js";
export * as nested6 from "./nested6/index.js";
export * as nested7 from "./nested7/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export type Status7 = "active" | "archived" | "pending";

export interface Item7 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status7;
	tags: readonly string[];
}

export type ItemPatch7 = Partial<Omit<Item7, "createdAt" | "id">>;

export type Getters7<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped7<T> = T extends Promise<infer U> ? U : T;

export type Result7<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary7 {
	byStatus: Record<Status7, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses7 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status7[];

export class Repository7<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result7<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch7 & Partial<T>,
	): Promise<Result7<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe7(value: Date): string;
export function describe7(value: number): string;
export function describe7(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem7(prefix: string, offset: number): Item7 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-7-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe7(offset)}`,
		status: statuses7[offset % statuses7.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize7(
	items: readonly Item7[],
	dependencies: number,
): Summary7 {
	const byStatus: Record<Status7, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example7(prefix: string): Promise<Summary7> {
	const repository = new Repository7<Item7>(`${prefix}repository7`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem7(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-7-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);

	const summary: Unwrapped7<ReturnType<typeof example7>> = summarize7(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters7<Summary7>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
