export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";
export * as nested5 from "./nested5/index.js";
export * as nested6 from "./nested6/index.js";
export * as nested7 from "./nested7/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary7 {
	labels: string[];
	total: number;
}

interface Entry7 {
	count: number;
	label: string;
}

const entries7: Entry7[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry7(entry: Entry7): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example7(prefix: string): Promise<Summary7> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const labels = entries7
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry7(entry));

	return { labels, total: labels.length + dependencyTotal };
}
