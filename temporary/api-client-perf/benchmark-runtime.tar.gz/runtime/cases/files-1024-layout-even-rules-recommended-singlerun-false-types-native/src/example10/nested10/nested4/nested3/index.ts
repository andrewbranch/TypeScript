export interface Summary2 {
	groups: number;
	total: number;
}

export interface Keyed2 {
	readonly key: string;
}

export class Cache2<K, V> {
	readonly #entries = new Map<K, V>();

	get(key: K, create: (key: K) => V): V {
		const existing = this.#entries.get(key);
		if (existing !== undefined) {
			return existing;
		}

		const created = create(key);
		this.#entries.set(key, created);
		return created;
	}
}

export function groupBy2<T, K extends PropertyKey>(
	items: readonly T[],
	getKey: (item: T) => K,
): Map<K, T[]> {
	const groups = new Map<K, T[]>();
	for (const item of items) {
		const key = getKey(item);
		const group = groups.get(key);
		if (group) {
			group.push(item);
		} else {
			groups.set(key, [item]);
		}
	}

	return groups;
}

export function pluck2<T, K extends keyof T>(
	items: readonly T[],
	key: K,
): T[K][] {
	return items.map((item) => item[key]);
}

export async function example2(prefix: string): Promise<Summary2> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const cache = new Cache2<string, Keyed2[]>();
	const items = cache.get(prefix, (key) => [
		{ key: `${key}a` },
		{ key: `${key}bb` },
		{ key: `${key}a` },
	]);
	const groups = groupBy2(pluck2(items, "key"), (key) => key.length);

	return { groups: groups.size, total: items.length + dependencyTotal };
}
