export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";
export * as nested5 from "./nested5/index.js";
export * as nested6 from "./nested6/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export type Status6 = "active" | "archived" | "pending";

export interface Item6 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status6;
	tags: readonly string[];
}

export type ItemPatch6 = Partial<Omit<Item6, "createdAt" | "id">>;

export type Getters6<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped6<T> = T extends Promise<infer U> ? U : T;

export type Result6<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary6 {
	byStatus: Record<Status6, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses6 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status6[];

export class Repository6<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result6<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch6 & Partial<T>,
	): Promise<Result6<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe6(value: Date): string;
export function describe6(value: number): string;
export function describe6(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem6(prefix: string, offset: number): Item6 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-6-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe6(offset)}`,
		status: statuses6[offset % statuses6.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize6(
	items: readonly Item6[],
	dependencies: number,
): Summary6 {
	const byStatus: Record<Status6, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example6(prefix: string): Promise<Summary6> {
	const repository = new Repository6<Item6>(`${prefix}repository6`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem6(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-6-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);

	const summary: Unwrapped6<ReturnType<typeof example6>> = summarize6(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters6<Summary6>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
