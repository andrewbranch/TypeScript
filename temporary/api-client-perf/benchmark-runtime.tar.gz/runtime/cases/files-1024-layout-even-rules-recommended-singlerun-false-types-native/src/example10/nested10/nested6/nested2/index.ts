export interface Summary1 {
	groups: number;
	total: number;
}

export interface Keyed1 {
	readonly key: string;
}

export class Cache1<K, V> {
	readonly #entries = new Map<K, V>();

	get(key: K, create: (key: K) => V): V {
		const existing = this.#entries.get(key);
		if (existing !== undefined) {
			return existing;
		}

		const created = create(key);
		this.#entries.set(key, created);
		return created;
	}
}

export function groupBy1<T, K extends PropertyKey>(
	items: readonly T[],
	getKey: (item: T) => K,
): Map<K, T[]> {
	const groups = new Map<K, T[]>();
	for (const item of items) {
		const key = getKey(item);
		const group = groups.get(key);
		if (group) {
			group.push(item);
		} else {
			groups.set(key, [item]);
		}
	}

	return groups;
}

export function pluck1<T, K extends keyof T>(
	items: readonly T[],
	key: K,
): T[K][] {
	return items.map((item) => item[key]);
}

export async function example1(prefix: string): Promise<Summary1> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const cache = new Cache1<string, Keyed1[]>();
	const items = cache.get(prefix, (key) => [
		{ key: `${key}a` },
		{ key: `${key}bb` },
		{ key: `${key}a` },
	]);
	const groups = groupBy1(pluck1(items, "key"), (key) => key.length);

	return { groups: groups.size, total: items.length + dependencyTotal };
}
