export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";
export * as nested5 from "./nested5/index.js";
export * as nested6 from "./nested6/index.js";
export * as nested7 from "./nested7/index.js";
export * as nested8 from "./nested8/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export type Status8 = "active" | "archived" | "pending";

export interface Item8 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status8;
	tags: readonly string[];
}

export type ItemPatch8 = Partial<Omit<Item8, "createdAt" | "id">>;

export type Getters8<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped8<T> = T extends Promise<infer U> ? U : T;

export type Result8<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary8 {
	byStatus: Record<Status8, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses8 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status8[];

export class Repository8<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result8<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch8 & Partial<T>,
	): Promise<Result8<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe8(value: Date): string;
export function describe8(value: number): string;
export function describe8(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem8(prefix: string, offset: number): Item8 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-8-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe8(offset)}`,
		status: statuses8[offset % statuses8.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize8(
	items: readonly Item8[],
	dependencies: number,
): Summary8 {
	const byStatus: Record<Status8, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example8(prefix: string): Promise<Summary8> {
	const repository = new Repository8<Item8>(`${prefix}repository8`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem8(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-8-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);

	const summary: Unwrapped8<ReturnType<typeof example8>> = summarize8(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters8<Summary8>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
