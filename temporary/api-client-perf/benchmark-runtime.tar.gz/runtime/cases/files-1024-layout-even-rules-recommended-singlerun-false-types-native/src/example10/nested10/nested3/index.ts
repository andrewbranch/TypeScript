export interface Summary2 {
	total: number;
}

export async function example2(prefix: string): Promise<Summary2> {
	await Promise.resolve();
	return { total: prefix.length + 2 };
}
