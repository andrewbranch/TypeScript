export interface Summary0 {
	labels: string[];
	total: number;
}

interface Entry0 {
	count: number;
	label: string;
}

const entries0: Entry0[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry0(entry: Entry0): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example0(prefix: string): Promise<Summary0> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const labels = entries0
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry0(entry));

	return { labels, total: labels.length + dependencyTotal };
}
