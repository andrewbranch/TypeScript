export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary4 {
	groups: number;
	total: number;
}

export interface Keyed4 {
	readonly key: string;
}

export class Cache4<K, V> {
	readonly #entries = new Map<K, V>();

	get(key: K, create: (key: K) => V): V {
		const existing = this.#entries.get(key);
		if (existing !== undefined) {
			return existing;
		}

		const created = create(key);
		this.#entries.set(key, created);
		return created;
	}
}

export function groupBy4<T, K extends PropertyKey>(
	items: readonly T[],
	getKey: (item: T) => K,
): Map<K, T[]> {
	const groups = new Map<K, T[]>();
	for (const item of items) {
		const key = getKey(item);
		const group = groups.get(key);
		if (group) {
			group.push(item);
		} else {
			groups.set(key, [item]);
		}
	}

	return groups;
}

export function pluck4<T, K extends keyof T>(
	items: readonly T[],
	key: K,
): T[K][] {
	return items.map((item) => item[key]);
}

export async function example4(prefix: string): Promise<Summary4> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const cache = new Cache4<string, Keyed4[]>();
	const items = cache.get(prefix, (key) => [
		{ key: `${key}a` },
		{ key: `${key}bb` },
		{ key: `${key}a` },
	]);
	const groups = groupBy4(pluck4(items, "key"), (key) => key.length);

	return { groups: groups.size, total: items.length + dependencyTotal };
}
