export interface Summary1 {
	labels: string[];
	total: number;
}

interface Entry1 {
	count: number;
	label: string;
}

const entries1: Entry1[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry1(entry: Entry1): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example1(prefix: string): Promise<Summary1> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const labels = entries1
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry1(entry));

	return { labels, total: labels.length + dependencyTotal };
}
