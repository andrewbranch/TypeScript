export interface Summary1 {
	failures: string[];
	total: number;
}

export type Result1<T> = { error: string; ok: false } | { ok: true; value: T };

export type Event1 =
	| { amount: number; kind: "deposit" }
	| { amount: number; kind: "withdrawal" }
	| { kind: "close"; reason: string };

export function parseAmount1(input: string): Result1<number> {
	const amount = Number(input);
	return Number.isFinite(amount) && amount >= 0
		? { ok: true, value: amount }
		: { error: `Invalid amount: ${input}`, ok: false };
}

export function applyEvent1(balance: number, event: Event1): Result1<number> {
	switch (event.kind) {
		case "close":
			return balance === 0
				? { ok: true, value: 0 }
				: { error: `Cannot close: ${event.reason}`, ok: false };
		case "deposit":
			return { ok: true, value: balance + event.amount };
		case "withdrawal":
			return event.amount > balance
				? { error: "Insufficient funds", ok: false }
				: { ok: true, value: balance - event.amount };
	}
}

export async function example1(prefix: string): Promise<Summary1> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const failures: string[] = [];
	let balance = 0;
	for (const input of [prefix.length.toString(), "12", "-3"]) {
		const amount = parseAmount1(input);
		if (!amount.ok) {
			failures.push(amount.error);
			continue;
		}

		const applied = applyEvent1(balance, {
			amount: amount.value,
			kind: "deposit",
		});
		if (applied.ok) {
			balance = applied.value;
		} else {
			failures.push(applied.error);
		}
	}

	return { failures, total: balance + dependencyTotal };
}
