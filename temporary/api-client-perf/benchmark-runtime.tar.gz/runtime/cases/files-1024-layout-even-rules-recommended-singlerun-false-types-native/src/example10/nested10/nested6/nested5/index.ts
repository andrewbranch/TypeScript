export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";

export interface Summary4 {
	total: number;
}

export async function example4(prefix: string): Promise<Summary4> {
	await Promise.resolve();
	return { total: prefix.length + 4 };
}
