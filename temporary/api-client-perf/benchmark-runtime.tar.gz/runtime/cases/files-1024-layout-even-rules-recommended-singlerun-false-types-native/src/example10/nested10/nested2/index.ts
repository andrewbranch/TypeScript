export type Status1 = "active" | "archived" | "pending";

export interface Item1 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status1;
	tags: readonly string[];
}

export type ItemPatch1 = Partial<Omit<Item1, "createdAt" | "id">>;

export type Getters1<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped1<T> = T extends Promise<infer U> ? U : T;

export type Result1<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary1 {
	byStatus: Record<Status1, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses1 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status1[];

export class Repository1<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result1<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch1 & Partial<T>,
	): Promise<Result1<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe1(value: Date): string;
export function describe1(value: number): string;
export function describe1(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem1(prefix: string, offset: number): Item1 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-1-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe1(offset)}`,
		status: statuses1[offset % statuses1.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize1(
	items: readonly Item1[],
	dependencies: number,
): Summary1 {
	const byStatus: Record<Status1, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example1(prefix: string): Promise<Summary1> {
	const repository = new Repository1<Item1>(`${prefix}repository1`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem1(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-1-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencyTotal = 0;

	const summary: Unwrapped1<ReturnType<typeof example1>> = summarize1(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters1<Summary1>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
