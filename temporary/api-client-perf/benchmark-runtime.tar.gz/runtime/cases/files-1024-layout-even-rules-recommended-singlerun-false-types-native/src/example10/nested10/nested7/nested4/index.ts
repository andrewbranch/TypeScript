export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary3 {
	labels: string[];
	total: number;
}

interface Entry3 {
	count: number;
	label: string;
}

const entries3: Entry3[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry3(entry: Entry3): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example3(prefix: string): Promise<Summary3> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const labels = entries3
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry3(entry));

	return { labels, total: labels.length + dependencyTotal };
}
