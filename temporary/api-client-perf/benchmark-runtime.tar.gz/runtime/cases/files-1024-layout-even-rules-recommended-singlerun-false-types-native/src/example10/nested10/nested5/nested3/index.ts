export type Status2 = "active" | "archived" | "pending";

export interface Item2 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status2;
	tags: readonly string[];
}

export type ItemPatch2 = Partial<Omit<Item2, "createdAt" | "id">>;

export type Getters2<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped2<T> = T extends Promise<infer U> ? U : T;

export type Result2<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary2 {
	byStatus: Record<Status2, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses2 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status2[];

export class Repository2<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result2<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch2 & Partial<T>,
	): Promise<Result2<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe2(value: Date): string;
export function describe2(value: number): string;
export function describe2(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem2(prefix: string, offset: number): Item2 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-2-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe2(offset)}`,
		status: statuses2[offset % statuses2.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize2(
	items: readonly Item2[],
	dependencies: number,
): Summary2 {
	const byStatus: Record<Status2, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example2(prefix: string): Promise<Summary2> {
	const repository = new Repository2<Item2>(`${prefix}repository2`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem2(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-2-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencyTotal = 0;

	const summary: Unwrapped2<ReturnType<typeof example2>> = summarize2(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters2<Summary2>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
