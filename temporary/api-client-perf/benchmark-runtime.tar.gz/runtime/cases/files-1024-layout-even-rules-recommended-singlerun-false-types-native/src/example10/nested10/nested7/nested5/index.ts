export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary4 {
	failures: string[];
	total: number;
}

export type Result4<T> = { error: string; ok: false } | { ok: true; value: T };

export type Event4 =
	| { amount: number; kind: "deposit" }
	| { amount: number; kind: "withdrawal" }
	| { kind: "close"; reason: string };

export function parseAmount4(input: string): Result4<number> {
	const amount = Number(input);
	return Number.isFinite(amount) && amount >= 0
		? { ok: true, value: amount }
		: { error: `Invalid amount: ${input}`, ok: false };
}

export function applyEvent4(balance: number, event: Event4): Result4<number> {
	switch (event.kind) {
		case "close":
			return balance === 0
				? { ok: true, value: 0 }
				: { error: `Cannot close: ${event.reason}`, ok: false };
		case "deposit":
			return { ok: true, value: balance + event.amount };
		case "withdrawal":
			return event.amount > balance
				? { error: "Insufficient funds", ok: false }
				: { ok: true, value: balance - event.amount };
	}
}

export async function example4(prefix: string): Promise<Summary4> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const failures: string[] = [];
	let balance = 0;
	for (const input of [prefix.length.toString(), "12", "-3"]) {
		const amount = parseAmount4(input);
		if (!amount.ok) {
			failures.push(amount.error);
			continue;
		}

		const applied = applyEvent4(balance, {
			amount: amount.value,
			kind: "deposit",
		});
		if (applied.ok) {
			balance = applied.value;
		} else {
			failures.push(applied.error);
		}
	}

	return { failures, total: balance + dependencyTotal };
}
