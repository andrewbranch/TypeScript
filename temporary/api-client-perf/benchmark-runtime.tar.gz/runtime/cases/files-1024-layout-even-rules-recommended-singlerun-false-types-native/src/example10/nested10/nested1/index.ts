export type Status0 = "active" | "archived" | "pending";

export interface Item0 {
	readonly createdAt: Date;
	readonly id: string;
	metadata?: Record<string, number | string>;
	name: string;
	status: Status0;
	tags: readonly string[];
}

export type ItemPatch0 = Partial<Omit<Item0, "createdAt" | "id">>;

export type Getters0<T> = {
	[K in keyof T & string as `get${Capitalize<K>}`]: () => T[K];
};

export type Unwrapped0<T> = T extends Promise<infer U> ? U : T;

export type Result0<T> = { error: Error; ok: false } | { ok: true; value: T };

export interface Summary0 {
	byStatus: Record<Status0, number>;
	dependencies: number;
	names: string[];
	tags: string[];
	total: number;
}

const statuses0 = [
	"active",
	"archived",
	"pending",
] as const satisfies readonly Status0[];

export class Repository0<T extends { readonly id: string }> {
	readonly #items = new Map<string, T>();

	constructor(private readonly label: string) {}

	get size(): number {
		return this.#items.size;
	}

	async findById(id: string): Promise<T | undefined> {
		await Promise.resolve();
		return this.#items.get(id);
	}

	list(predicate?: (item: T) => boolean): T[] {
		const items = [...this.#items.values()];
		return predicate ? items.filter(predicate) : items;
	}

	async save(item: T): Promise<Result0<T>> {
		try {
			await Promise.resolve();
			if (!item.id) {
				return {
					error: new Error(`${this.label} items need an id`),
					ok: false,
				};
			}

			this.#items.set(item.id, item);
			return { ok: true, value: item };
		} catch (error) {
			return {
				error: error instanceof Error ? error : new Error("Unknown failure"),
				ok: false,
			};
		}
	}

	async update(
		id: string,
		patch: ItemPatch0 & Partial<T>,
	): Promise<Result0<T>> {
		const existing = await this.findById(id);
		if (existing === undefined) {
			return { error: new Error(`${this.label} has no item ${id}`), ok: false };
		}

		return this.save({ ...existing, ...patch });
	}
}

export function describe0(value: Date): string;
export function describe0(value: number): string;
export function describe0(value: Date | number): string {
	return typeof value === "number" ? value.toFixed(2) : value.toISOString();
}

export function createItem0(prefix: string, offset: number): Item0 {
	return {
		createdAt: new Date(offset * 1000),
		id: `${prefix}-0-${offset.toString()}`,
		metadata:
			offset % 3 === 0 ? { priority: offset, source: prefix } : undefined,
		name: `Item ${describe0(offset)}`,
		status: statuses0[offset % statuses0.length],
		tags: offset % 2 === 0 ? ["even", prefix] : ["odd"],
	};
}

export function summarize0(
	items: readonly Item0[],
	dependencies: number,
): Summary0 {
	const byStatus: Record<Status0, number> = {
		active: 0,
		archived: 0,
		pending: 0,
	};
	for (const item of items) {
		byStatus[item.status] += 1;
	}

	return {
		byStatus,
		dependencies,
		names: items
			.map((item) => item.name.toUpperCase())
			.sort((a, b) => a.localeCompare(b)),
		tags: [...new Set(items.flatMap((item) => item.tags))].sort(),
		total: items.length,
	};
}

export async function example0(prefix: string): Promise<Summary0> {
	const repository = new Repository0<Item0>(`${prefix}repository0`);
	const results = await Promise.all(
		Array.from({ length: 4 }, (_, offset) =>
			repository.save(createItem0(prefix, offset)),
		),
	);

	const failures = results.filter((result) => !result.ok);
	if (failures.length > 0) {
		throw new Error(`Failed to save ${failures.length.toString()} items`);
	}

	const archived = await repository.update(`${prefix}-0-0`, {
		status: "archived",
	});
	if (!archived.ok) {
		throw archived.error;
	}

	const dependencyTotal = 0;

	const summary: Unwrapped0<ReturnType<typeof example0>> = summarize0(
		repository.list((item) => item.status !== "pending"),
		dependencyTotal,
	);
	const getters: Pick<Getters0<Summary0>, "getTotal"> = {
		getTotal: () => summary.total,
	};

	return { ...summary, total: getters.getTotal() };
}
