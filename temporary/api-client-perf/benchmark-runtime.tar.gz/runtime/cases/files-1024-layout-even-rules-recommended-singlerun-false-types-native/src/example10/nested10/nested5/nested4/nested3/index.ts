export interface Summary2 {
	labels: string[];
	total: number;
}

interface Entry2 {
	count: number;
	label: string;
}

const entries2: Entry2[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry2(entry: Entry2): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example2(prefix: string): Promise<Summary2> {
	const dependencyTotal = 0;
	await Promise.resolve();

	const labels = entries2
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry2(entry));

	return { labels, total: labels.length + dependencyTotal };
}
