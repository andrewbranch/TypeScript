export * as nested1 from "./nested1/index.js";
export * as nested2 from "./nested2/index.js";
export * as nested3 from "./nested3/index.js";
export * as nested4 from "./nested4/index.js";
export * as nested5 from "./nested5/index.js";

import { example0, type Summary0 } from "./nested1/index.js";
import { example1, type Summary1 } from "./nested2/index.js";

export interface Summary5 {
	labels: string[];
	total: number;
}

interface Entry5 {
	count: number;
	label: string;
}

const entries5: Entry5[] = [
	{ count: 1, label: "alpha" },
	{ count: 2, label: "beta" },
	{ count: 3, label: "gamma" },
];

export function formatEntry5(entry: Entry5): string {
	return `${entry.label} (${entry.count.toString()})`;
}

export async function example5(prefix: string): Promise<Summary5> {
	const dependencySummaries: [Summary0, Summary1] = await Promise.all([
		example0(prefix),
		example1(prefix),
	]);
	const dependencyTotal = dependencySummaries.reduce(
		(total, summary) => total + summary.total,
		0,
	);
	await Promise.resolve();

	const labels = entries5
		.filter((entry) => entry.count > 1)
		.map((entry) => prefix + formatEntry5(entry));

	return { labels, total: labels.length + dependencyTotal };
}
