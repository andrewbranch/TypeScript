export interface Summary0 {
	total: number;
}

export async function example0(prefix: string): Promise<Summary0> {
	await Promise.resolve();
	return { total: prefix.length + 0 };
}
